from flask import Flask, render_template, Response, jsonify
import cv2
import mediapipe as mp
import numpy as np
import tensorflow as tf
import warnings
import logging

# Suppress warnings
warnings.filterwarnings("ignore")

# Setup logging
logging.basicConfig(level=logging.INFO)

app = Flask(__name__)

# Load the trained model
model = tf.keras.models.load_model('cnn_model.h5')

# Initialize Mediapipe Hands solution
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1, min_detection_confidence=0.8,
                       min_tracking_confidence=0.8)

# Define labels and their corresponding images
labels_dict = {
    0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E',
    5: 'F', 6: 'G', 7: 'H', 8: 'I', 9: 'J',
    10: 'K', 11: 'L', 12: 'M', 13: 'N', 14: 'O',
    15: 'P', 16: 'Q', 17: 'R', 18: 'S', 19: 'T',
    20: 'U', 21: 'V', 22: 'W', 23: 'X', 24: 'Y', 25: 'Z'
}

current_sign = ''
confidence_threshold = 0.6  # Adjusted confidence threshold

def extract_features(hand_landmarks):
    data_aux = []
    x_ = [landmark.x for landmark in hand_landmarks]
    y_ = [landmark.y for landmark in hand_landmarks]

    for landmark in hand_landmarks:
        data_aux.append(landmark.x - min(x_))
        data_aux.append(landmark.y - min(y_))

    # Convert to numpy array and flatten for Dense layer input
    data_aux = np.array(data_aux)
    data_aux = data_aux.flatten()

    # Normalize the feature vector
    if np.max(data_aux) - np.min(data_aux) != 0:
        data_aux = (data_aux - np.min(data_aux)) / (np.max(data_aux) - np.min(data_aux))

    # Pad or trim the features to match the expected input shape (100,)
    max_sequence_length = 100
    if len(data_aux) < max_sequence_length:
        data_aux = np.pad(data_aux, (0, max_sequence_length - len(data_aux)), 'constant')
    else:
        data_aux = data_aux[:max_sequence_length]

    return data_aux

def generate_frames():
    global current_sign
    cap = cv2.VideoCapture(0)
    while True:
        success, frame = cap.read()
        if not success:
            break

        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(frame_rgb)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                data_aux = extract_features(hand_landmarks.landmark)
                data_aux = data_aux.reshape(1, 100)
                prediction = model.predict(data_aux)
                predicted_label = np.argmax(prediction, axis=1)[0]
                predicted_confidence = np.max(prediction)

                logging.info(f"Prediction: {labels_dict[predicted_label]}, Confidence: {predicted_confidence}")

                # Apply confidence threshold
                if predicted_confidence >= confidence_threshold:
                    current_sign = labels_dict.get(predicted_label, '')
                else:
                    current_sign = ''  # Reset if confidence is below threshold

                # Draw the detected sign on the frame
                cv2.putText(frame, current_sign, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)
        else:
            current_sign = ''  # No hand detected

        # Encode frame to JPEG format
        ret, buffer = cv2.imencode('.jpg', frame)
        if not ret:
            break
        frame = buffer.tobytes()

        # Yield the frame in JPEG format
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/current_sign')
def current_sign_route():
    return jsonify({'character': current_sign})

if __name__ == "__main__":
    app.run(debug=True)
